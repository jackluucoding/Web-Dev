// greetings
greetings();

var number1=2;
var number2=4;
document.write("<h2>Multiplying two numbers</h2>");
document.write(number1+'*'+number2+"="+multiply(number1,number2));
