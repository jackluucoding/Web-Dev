/* Greetings Example */
function greetings() {

}


function multiply(number1,number2){

}

function add(number1,number2){

}


function createTable(rows, cols)
{
  
}
